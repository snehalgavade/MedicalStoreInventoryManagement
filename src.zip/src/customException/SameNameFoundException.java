package customException;

public class SameNameFoundException extends Exception {
public SameNameFoundException(String message) {
	super(message);
}
}
