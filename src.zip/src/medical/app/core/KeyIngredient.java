package medical.app.core;

public enum KeyIngredient {
	METHYLCOBALAMIN,ALPHA_LIPOIC_ACID,INOSITOL;

}
